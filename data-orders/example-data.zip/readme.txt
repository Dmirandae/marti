====================================
Minimum spanning trees for test0.dat
====================================

File= test0-mst.kml

1. Load test0.dat

./mt05XXX test0.dat test0-mst.kml

2. write the individual tracks
 
 [k]ml +
 [w]rite all


==========================
TUI (text user interfase)
==========================

A. File = join1-track1-joint2.kml

1. Set parameters number one (1):

[c]ut value= 0.25
[r]ules:
lmax= 0.75
lmin= 0.5
lmax-line=1
[m]in congruence = 0.8

2. Analysis with the set number one
 Joint [u] 1 6
 Track [a]
 
3. set the parameters number two (2)

[c]ut value= 0.5
[r]ules:
lmax= 1.5
lmin= 1
lmax-line=2
[m]in congruence = 0.8

4. Analysis with the set number two
 Joint [u] 7 9
 
 5. write the generalized tracks
 
 [k]ml +
 writ[e] generalized tracks

B. File = track1-joint2.kml

1. Set parameters number one (1):

[c]ut value= 0.25
[r]ules:
lmax= 0.75
lmin= 0.5
lmax-line=1
[m]in congruence = 0.8

2. Analysis with the set number one
 track [a]
 
3. set the parameters number two (2)

[c]ut value= 0.5
[r]ules:
lmax= 1.5
lmin= 1
lmax-line=2
[m]in congruence = 0.8

4. Analysis with the set number two
 Joint [u] 7 12
 
 5. write the generalized tracks
 
 [k]ml +
 writ[e] generalized tracks


==========================
COMMAND LINE INTERFASE   
==========================

A. file= croizat0.kml

...........................
	commands1.txt          .
...........................						   
		set cv 0.25       .
		set lmin 0.75     .  
		set lmax 0.5      .
		set maxline 1     .
		set ci 0.8        .
		kmlgen            .
		croizat0          .
...........................

./mt05XXX test0.dat croizat0.kml commands1.txt

joint [u]
track [a]
joint [u]


B. file= croizat1.kml

...........................
	commands2.txt          .
...........................						   
		set cv 0.25       .
		set lmin 0.75     .  
		set lmax 0.5      .
		set maxline 1     .
		set ci 0.8        .
		kmlgen            .
		croizat1          .
...........................

./mt05XXX test0.dat croizat1.kml commands1.txt

track [a]
joint [u]


==================
Graphical results
==================

test0.pdf
